<!--# jogo-pong-2d-projeto-unity-->
 <h1>CURSO: CRIE O JOGO PONG 2D NA UNITY E C# - Desenvolvendo Jogos</h1>
 Nesse repositório você encontra o projeto (com todos os arquivos) do nosso Curso Gratuito "CRIE O JOGO PONG 2D NA UNITY E C#", do meu canal no YouTube, Desenvolvendo Jogos.
 <br>
 Espero que se divirta bastante e aprenda diversas coisas novas com ele :)
 <br>
 Link da playlist do curso: https://www.youtube.com/playlist?list=PLzjwaizNOg6Sk0w3EMlka6X9fM6CTEhJr
